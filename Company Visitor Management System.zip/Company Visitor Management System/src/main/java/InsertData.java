

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertData
 */
@WebServlet("/InsertData")
public class InsertData extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public InsertData() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response); // Forward GET requests to the doPost() method
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
		//PrintWriter out = response.getWriter(); 
		String id=request.getParameter("id");
		String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");
        String number = request.getParameter("phone");
        String address = request.getParameter("address");
        String whom_to_meet = request.getParameter("whom");
        String department = request.getParameter("department");
        String reason = request.getParameter("reason");
        
        try {
            Class.forName("com.mysql.jdbc.Driver"); 
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/visitor","root","root"); 
            PreparedStatement st = con.prepareStatement("INSERT INTO VisitorData (id,fullname, email, number, address, whom_to_meet, department, reason) VALUES (?,?, ?, ?, ?, ?, ?, ?)");
            
            st.setString(1, id);
            st.setString(2, fullname);
            st.setString(3, email);
            st.setString(4, number);
            st.setString(5, address);
            st.setString(6, whom_to_meet);
            st.setString(7, department);
            st.setString(8, reason);
            
            int rowsInserted = st.executeUpdate();
            if (rowsInserted > 0) {
                PrintWriter out = response.getWriter();
                out.println("<html><body><b>Successfully Inserted</b></body></html>");
            }
            
            st.close();
            con.close(); 
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}
