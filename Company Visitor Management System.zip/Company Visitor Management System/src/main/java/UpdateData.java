import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateData")
public class UpdateData extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html"); 
        PrintWriter out = response.getWriter(); 
        try{ 
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            String whomToMeet = request.getParameter("whomToMeet");
            String department = request.getParameter("department");
            String reason = request.getParameter("reason");
            
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/visitor","root","root");  
                          
            PreparedStatement st=con.prepareStatement("UPDATE visitorData SET fullname=?, email=?, number=?, address=?, whom_to_meet=?, department=?, reason=? WHERE id=?");  
                    
            st.setString(1, name);
            st.setString(2, email);
            st.setString(3, phone);
            st.setString(4, address);
            st.setString(5, whomToMeet);
            st.setString(6, department);
            st.setString(7, reason);
            st.setString(8, id);
            
            int rowsUpdated = st.executeUpdate();
            
            if(rowsUpdated > 0) {
                out.println("<html><body><b>Successfully Updated</b></body></html>");
            } else {
                out.println("<html><body><b>No record found with the given id</b></body></html>");
            }
            
            st.close();
            con.close();
        } catch(Exception e){ 
            e.printStackTrace();
        } finally {
            out.close();
        }
    }
}
